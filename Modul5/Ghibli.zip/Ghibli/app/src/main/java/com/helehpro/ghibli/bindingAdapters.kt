package com.helehpro.ghibli

import android.view.View
import android.widget.ImageView
import androidx.core.net.toUri
import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.helehpro.ghibli.ui.GhibliApiStatus
import com.helehpro.ghibli.ui.GhibliListAdapter
import com.helehpro.ghibli.network.Ghibli

@BindingAdapter("listData")
fun bindRecyclerView(recyclerView: RecyclerView, data: List<Ghibli>?) {
    val adapter = recyclerView.adapter as GhibliListAdapter
    adapter.submitList(data)
}

@BindingAdapter("apiStatus")
fun bindStatus(statusImageView: ImageView, status: GhibliApiStatus?) {
    when(status){
        GhibliApiStatus.LOADING -> {
            statusImageView.visibility = View.VISIBLE
            statusImageView.setImageResource(R.drawable.loading_animation)
        }
        GhibliApiStatus.DONE -> {
            statusImageView.visibility = View.GONE
        }
        else -> {
            statusImageView.visibility = View.VISIBLE
            statusImageView.setImageResource(R.drawable.ic_connection_error)
        }
    }
}

@BindingAdapter("imageUrl")
fun bindImage(imgView: ImageView, image: String?) {
    image?.let {
        val imgUri = image.toUri().buildUpon().scheme("https").build()
        Glide.with(imgView.context)
            .load(imgUri)
            .into(imgView)
    }
}