package com.helehpro.ghibli.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.helehpro.ghibli.network.Ghibli
import com.helehpro.ghibli.network.GhibliApi
import kotlinx.coroutines.launch

enum class GhibliApiStatus {LOADING, ERROR, DONE}

class GhibliViewModel: ViewModel() {
    private val _status = MutableLiveData<GhibliApiStatus>()
    val status : LiveData<GhibliApiStatus> = _status

    private val _ghiblis = MutableLiveData<List<Ghibli>>()
    val ghiblis : LiveData<List<Ghibli>> = _ghiblis

    private val _ghibli = MutableLiveData<Ghibli>()
    val ghibli : LiveData<Ghibli> = _ghibli

    fun getGhibliList(){
        _status.value = GhibliApiStatus.LOADING
        viewModelScope.launch {
            try {
                _ghiblis.value = GhibliApi.retrofitService.getGhibli()
                _status.value = GhibliApiStatus.DONE
            }catch (e: Exception){
                e.printStackTrace()
                _status.value = GhibliApiStatus.ERROR
            }

        }

    }

    fun onGhibliCliked(Ghibli: Ghibli){
        _ghibli.value = Ghibli
    }
}

