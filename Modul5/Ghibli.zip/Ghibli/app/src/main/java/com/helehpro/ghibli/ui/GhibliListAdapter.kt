package com.helehpro.ghibli.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.helehpro.ghibli.databinding.ListViewItemBinding
import com.helehpro.ghibli.network.Ghibli

class GhibliListAdapter(val clickListener: GhibliListener) :
    ListAdapter<Ghibli, GhibliListAdapter.GhibliViewHolder>(DiffCallback) {

    class GhibliViewHolder(var binding: ListViewItemBinding):
        RecyclerView.ViewHolder(binding.root){
        fun bind(clickListener: GhibliListener, ghibli: Ghibli){
            binding.ghibli = ghibli
            binding.clickListener = clickListener
            binding.executePendingBindings()
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Ghibli>() {

        override fun areItemsTheSame(oldItem: Ghibli, newItem: Ghibli): Boolean{
            return oldItem.title == newItem.title
        }

        override fun areContentsTheSame(oldItem: Ghibli, newItem: Ghibli): Boolean {
            return oldItem.description == newItem.description
        }

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GhibliViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return GhibliViewHolder(
            ListViewItemBinding.inflate(layoutInflater, parent, false)
        )
    }

    override fun onBindViewHolder(holder: GhibliViewHolder, position: Int) {
        val ghibli = getItem(position)
        holder.bind(clickListener, ghibli)
    }
}

class GhibliListener(val clickListener: (ghibi: Ghibli) -> Unit) {
    fun onClick(ghibi: Ghibli) = clickListener(ghibi)
}
