package com.helehpro.ghibli.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.helehpro.ghibli.R
import com.helehpro.ghibli.databinding.FragmentGhibliListBinding

class GhibliListFragment: Fragment() {

   private val viewModel: GhibliViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceSate: Bundle?
    ): View? {
        val binding = FragmentGhibliListBinding.inflate(inflater)
        viewModel.getGhibliList()
        binding.lifecycleOwner = this
        binding.viewModel = viewModel
        binding.recyclerView.adapter = GhibliListAdapter(GhibliListener{
            ghibli -> viewModel.onGhibliCliked(ghibli)
            findNavController()
                .navigate(R.id.action_ghibliListFragment_to_ghibliDetailFragment)
        })
        return binding.root
    }
}